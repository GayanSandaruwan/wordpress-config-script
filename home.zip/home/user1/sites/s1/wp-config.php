<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dbname' );

/** MySQL database username */
define( 'DB_USER', 'dbuser' );

/** MySQL database password */
define( 'DB_PASSWORD', 'dbpass' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'Ib2hi07FO,8i)atHZ$8O5(Pa[/W,6nC!)0L6+ g/sV*H5G3@<is76qb1eFn]4`l,' );
define( 'SECURE_AUTH_KEY',   '-Gv.WKH0;)^-q7x7=Shm=R)z}i{B,8JURqb1pwZ-kA)Xb.MIHs^Bo8}|@%1vfxKo' );
define( 'LOGGED_IN_KEY',     'WL4Co1rl$dBHnsHDXB_=,S=K{?,nLhUhn6p+t]%R60^i_}kZ{9;[L7T%qa1g9`zf' );
define( 'NONCE_KEY',         '}$fcS D5I0WPOQC]/6dN@{Y2Fe:,;T(L%?}iTd%dc<CA3K_{@T1~>!-_(BTdaO{4' );
define( 'AUTH_SALT',         '-X;$z=(=uZJ7yi4Qvn}Dg3V]x{S{S-DWfadgUjbcn5bLbvAEoJ;/Ig`+aGWz#.WMV' );
define( 'SECURE_AUTH_SALT',  '2B<k&*7sCcg-X)fdsg]hdo.@,( &O)np,YU3LMqYNm,J( |wX2r, wL$%#X?d/' );
define( 'LOGGED_IN_SALT',    'IR@KI`BMuH0R4PRQ>Tj.pr7)oP*]sgh{/L;~2[]$CM:wt_F/-1.{?s-*h?M>vrwK' );
define( 'NONCE_SALT',        'Q-a1W#{QHw^xZ6ZG{@:bASL/+DGSHHgs-j2TC!K1KR)u&9~[Uy}b/W;X#@Xii?z%' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* GridPane site routing */
//define('WP_HOME', 'https://t2.blogbing.net');
//define('WP_SITEURL', 'https://t2.blogbing.net');

/* GridPane Secure Debug */
define('WP_DEBUG', false);

/* GridPane Cache Settings */
define('WP_REDIS_SELECTIVE_FLUSH', true);
define('WP_CACHE', false);
define('WP_CACHE_KEY_SALT', 'eechigiePho5dii9-redis_object_cache_for_mysite');

/* GridPane Elasticpress */
//define('EP_HOST', 'http://127.0.0.1:9200');

/* GridPane Mailer */
//include __DIR__ . '/sendgrid-wp-configs.php';

/* GridPane Cron */
//define('DISABLE_WP_CRON', true);

/* GridPane HTTP2 disable concat - mitigate CVE-2018-6389 */
//define('CONCATENATE_SCRIPTS', false);

/* GridPane wpFail2Ban integration */
//include __DIR__ . '/wp-fail2ban-configs.php';

/* GridPane WP Ultimo integration */
//include __DIR__ . '/gp-ultimo-configs.php';
//define('SUNRISE', true);


/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
